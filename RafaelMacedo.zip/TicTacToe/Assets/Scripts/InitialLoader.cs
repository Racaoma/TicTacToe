﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitialLoader : MonoBehaviour
{

	// Use this for initialization
	void Start ()
    {
        Screen.SetResolution(1024, 768, false);
    }
}
